let balance = Number(localStorage.getItem("walletBalance")) || 0;
let history = JSON.parse(localStorage.getItem("walletHistory")) || [];

function saveWallet() {
  localStorage.setItem("walletBalance", balance.toString());
  localStorage.setItem("walletHistory", JSON.stringify(history));
}

function updateBalance() {
  document.getElementById("balance").innerText = balance.toFixed(2);
  document.getElementById("transactionCount").innerText = `${history.length} record${history.length === 1 ? "" : "s"}`;
}

function showMessage(text, type) {
  const message = document.getElementById("message");
  message.textContent = text;
  message.className = `message ${type}`;
}

function updateHistory() {
  const list = document.getElementById("historyList");
  list.innerHTML = "";

  if (!history.length) {
    list.innerHTML = '<div class="empty-state">No transactions yet.</div>';
    return;
  }

  [...history].reverse().forEach(item => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = item;
    list.appendChild(div);
  });
}

function addVoucher() {
  const code = document.getElementById("voucherCode").value.trim().toUpperCase();
  const amount = Number(document.getElementById("voucherAmount").value);

  if (!code || !amount || amount <= 0) {
    showMessage("Enter a valid voucher code and amount.", "error");
    return;
  }

  balance += amount;
  history.push(`✅ <strong>Voucher added</strong><br>Code: ${code}<br>Amount: R${amount.toFixed(2)}<br>${new Date().toLocaleString()}`);

  document.getElementById("voucherCode").value = "";
  document.getElementById("voucherAmount").value = "";

  saveWallet();
  updateBalance();
  updateHistory();
  showMessage("Voucher added successfully.", "success");
}

function redeemVoucher() {
  const amount = Number(document.getElementById("redeemAmount").value);
  const method = document.getElementById("redeemMethod").value;

  if (!amount || amount <= 0) {
    showMessage("Enter a valid redeem amount.", "error");
    return;
  }

  if (amount > balance) {
    showMessage("Insufficient wallet balance.", "error");
    return;
  }

  balance -= amount;
  history.push(`🔁 <strong>Voucher redeemed</strong><br>Method: ${method}<br>Amount: R${amount.toFixed(2)}<br>${new Date().toLocaleString()}`);

  document.getElementById("redeemAmount").value = "";

  saveWallet();
  updateBalance();
  updateHistory();
  showMessage("Voucher redeemed successfully.", "success");
}

updateBalance();
updateHistory();
